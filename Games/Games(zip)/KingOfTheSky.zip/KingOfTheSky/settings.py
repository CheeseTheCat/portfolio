# game options/settings
TITLE = "King OF The Sky"
WIDTH = 640 # 20 tiles
HEIGHT = 800 # 25 tiles
FPS = 60

# Player properties
PLAYER_ACC = 0.07
PLAYER_FRICTION = -0.05
PLAYER_GRAV = 0.1

# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
LIGHTBLUE = (0, 155, 155)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
ORANGE = (255,116,0)

BGCOLOR = DARKGREY

TILESIZE = 32
GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE

TITLE_FONT = 'arial'
